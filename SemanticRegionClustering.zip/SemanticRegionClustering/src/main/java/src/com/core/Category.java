package src.com.core;

public class Category {
	
	public String name = "Thing";
	public double weight = 1.0;
	
	public Category(String name, double weight) {
		this.name = name;
		this.weight = weight;
	}
	
}
